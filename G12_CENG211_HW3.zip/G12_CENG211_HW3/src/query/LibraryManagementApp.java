package query;

public class LibraryManagementApp {

	public static void main(String[] args) {
		Query query = new Query();
		query.menu();
		query.getManage().searchItem("History of Art", "book");
		query.getManage().searchItem("Animal Farm");
            
        }
	}
