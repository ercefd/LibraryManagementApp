package query;

import management.Management;
import librarydatas.Items;
public class Query {
	private Management manage = new Management();
	
	
	


	public void menu() {
		for (Items item : manage.getLibraryItems()) {
            System.out.println("Item number: " + item.getItemNumber() +
            				   " Title: " + item.getTitle() +
            				   " Item Type: " + item.getItemType() +
            				   " Borrowing Days: " + item.getCustomer().getBorrowedDays() +
            				   " days Exceed: " + item.exceedenceChecker() +
            				   " Total Price: $" + item.TotalPrice());
	}
	}

	public Management getManage() {
		return manage;
	}


	public void setManage(Management manage) {	
		this.manage = manage;
	}
		
	}
