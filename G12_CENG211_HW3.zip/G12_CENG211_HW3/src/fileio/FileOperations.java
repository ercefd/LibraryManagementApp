package fileio;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import librarydatas.Items;
import librarydatas.Magazine;
import librarydatas.Book;
import librarydatas.General;
import librarydatas.Customer;
import librarydatas.Student;
public class FileOperations {
    private static final String CSV_FILE_PATH = "items.csv";
    static SimpleDateFormat myFormat = new SimpleDateFormat("dd/MM/yyyy");
    

    public static ArrayList<Items> readLibraryItems() {
    	ArrayList<Items> libraryItems = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(CSV_FILE_PATH))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(";");
                if (data.length == 9 ) {
                    String itemNumber = data[0].trim();
                    String title = data[1].trim();
                    String priority = data[2].trim();
                    String itemType = data[3].trim();
                    String authorOrGenre = data[4].trim();
                    String publisherOrProducer = data[5].trim();
                    String customerType = data[6].trim();
                    String startBorrow = data[7].trim();
                    String endBorrow = data[8].trim();
                    
                    // borrowing daysi burda hesaplattım
        			Date borrowStart = myFormat.parse(startBorrow);
        			Date borrowEnd = myFormat.parse(endBorrow);
        			Customer customer;
        			
        			if (customerType.equalsIgnoreCase("general")) {
        				customer= new General(borrowStart, borrowEnd);
        			}
        			else {
        				customer= new Student(borrowStart, borrowEnd,customerType );
        			}
                    
        			//book ve magazin olarak ayrı ayrı attım arraylistlere çünkü tot price hesaplarken muhtemelen işe yarıcak
        			if(itemType.equals("book")) {
                    
					
					Book book = new Book(itemNumber, title, priority, itemType,
                            authorOrGenre, publisherOrProducer, customer);

                    libraryItems.add(book);
        			}
        			
        			if(itemType.equals("magazine")) {
        		    	Magazine magazine = new Magazine(itemNumber, title, priority, itemType,
        		        		authorOrGenre, publisherOrProducer, customer );
        		        
        		    libraryItems.add(magazine);
                }
                
            }
        }
        }catch (IOException | ParseException e) {
            e.printStackTrace();
        } 
        return libraryItems;
    }
    
 
}

    

