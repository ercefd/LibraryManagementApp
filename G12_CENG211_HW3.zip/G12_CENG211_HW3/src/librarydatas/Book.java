package librarydatas;

public class Book extends Items{
	public Book(String itemNumber, String title, String priority, String itemType, String authorOrGenre,
			String publisherOrProducer, Customer customer) {
		
		super(itemNumber, title, priority, itemType, authorOrGenre, publisherOrProducer, customer);
		this.pricePerDay = 5;
	}
	@Override
	public int lateCharge() {
		long borrowDays=this.customer.getBorrowedDays();
		if(borrowDays>10) {
			return 5;
		}
		else {
			return 0;
		}
		
	}

	public String exceedenceChecker() {
	    if (this.customer.getBorrowedDays() <= 10) {
	        return "Not Exceeds";
	    } else {
	        return (this.customer.getBorrowedDays()-10)+" Days Exceeds";
	    }
	}
	
	

	
	
}
