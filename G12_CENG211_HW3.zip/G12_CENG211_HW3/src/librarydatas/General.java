package librarydatas;

import java.util.Date;

public class General extends Customer{
	
	public General(Date startDate, Date endDate) {
		super(startDate, endDate);
		
	}
	public double discount() {
		return 0.0;
	}
	

}
