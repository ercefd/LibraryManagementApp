package librarydatas;

import java.util.Date;

public class Student extends Customer{
	private String studentType;
	
	public Student(Date startDate, Date endDate , String studentType) {
		super(startDate, endDate);
		this.studentType = studentType;
		
	}

	public double discount() {
		if (studentType.equalsIgnoreCase("studentWScholar")) {
			return 0.3;
			}
		else {
			return 0.2;
			}
	}	
		
	
	
	
	
	public String getStudentType() {
		return studentType;
	}

	public void setStudentType(String studentType) {
		this.studentType = studentType;
	}
	
	
	




}
