package librarydatas;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;


public abstract class Customer {
	
	protected Date startDate;
	protected Date endDate;
	protected long borrowedDays;
	


	

	public Customer(Date startDate, Date endDate) {
		
		this.startDate = startDate;
		this.endDate = endDate;
		this.borrowedDays = borrowDays();
	}
	public long borrowDays() {
		
		long bDays = endDate.getTime() - startDate.getTime();
		long borrowingDays = TimeUnit.DAYS.convert(bDays, TimeUnit.MILLISECONDS);
        return borrowingDays;
	}
	public abstract double discount();

	public Date getStartDate() {
		return startDate;
	}


	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}


	public Date getEndDate() {
		return endDate;
	}


	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	public long getBorrowedDays() {
		return borrowedDays;
	}


	public void setBorrowedDays(int borrowedDays) {
		this.borrowedDays = borrowedDays;
	}

	
	
}

