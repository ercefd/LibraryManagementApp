package librarydatas;

public interface IBorrowing {
	
	public long borrowingCharge();
	public int lateCharge();
		
	
}	
