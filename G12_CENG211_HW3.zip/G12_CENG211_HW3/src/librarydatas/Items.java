package librarydatas;

public abstract class Items implements IBorrowing{
	
	
	protected String itemNumber;
	protected  String title;
	protected  String priority;
	protected  String itemType;
	protected  String authorOrGenre;
	protected  String publisherOrProducer;
	protected  Customer customer;
	protected  int pricePerDay;
	
	public Items(String  itemNumber, String title, String priority, String itemType, String authorOrGenre,
			String publisherOrProducer, Customer customer) {
		
		this.itemNumber = itemNumber;
		this.title = title;
		this.priority = priority;
		this.itemType = itemType;
		this.authorOrGenre = authorOrGenre;
		this.publisherOrProducer = publisherOrProducer;
		this.customer = customer;
	}

	

	

	
	@Override
	public long borrowingCharge() {
		if(this.priority.equalsIgnoreCase("highly significant")) {
			return this.customer.borrowedDays*this.pricePerDay*2;
		}else if(this.priority.equalsIgnoreCase("invaluable")){
			return this.customer.borrowedDays*this.pricePerDay*3;
		}else {
			return this.customer.borrowedDays*this.pricePerDay*1;
		}
		
	}	
	@Override
	public abstract int lateCharge ();	
	
	public abstract String exceedenceChecker();
	
	public double TotalPrice() {
		double totPrice = (this.borrowingCharge()+ this.lateCharge())*(1-getCustomer().discount());
		
		return totPrice;
	}

	
	
	

	public String getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(String  itemNumber) {
		this.itemNumber = itemNumber;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public String getAuthorOrGenre() {
		return authorOrGenre;
	}

	public void setAuthorOrGenre(String authorOrGenre) {
		this.authorOrGenre = authorOrGenre;
	}

	public String getPublisherOrProducer() {
		return publisherOrProducer;
	}

	public void setPublisherOrProducer(String publisherOrProducer) {
		this.publisherOrProducer = publisherOrProducer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	

	public int getPricePerDay() {
		return pricePerDay;
	}

	public void setPricePerDay(int pricePerDay) {
		this.pricePerDay = pricePerDay;
	}
	
	
	
	


}
