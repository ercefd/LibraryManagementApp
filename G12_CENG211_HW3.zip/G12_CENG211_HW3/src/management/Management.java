package management;

import java.util.ArrayList;

import fileio.FileOperations;
import librarydatas.Items;

public class Management implements ISearchable{
	

	private ArrayList<Items> libraryItems;

	
	public Management() {
		this.libraryItems = FileOperations.readLibraryItems();
		
	}
	 
	 @Override
	public void searchItem(String title) {
		 boolean exist = false;
		 for(Items item: libraryItems) {
			if (item.getTitle().equals(title)) {
				exist = true;
				System.out.println("Exist Item Number: " + item.getItemNumber() +
                        " Title: " + item.getTitle() +
                        " Item Type: " + item.getItemType() +
                        " Borrowing Days: " + item.getCustomer().borrowDays() +
                        " Exceeds: " + item.exceedenceChecker() +
                        " Total Price: $" + item.TotalPrice());
                
                break;
            }
			}
			
		 if (exist == false) {
                System.out.println("Does not exist");
            }
		
		
	}
	 
	public void searchItem(String title, String itemType) {
		boolean exist = false;
		 for(Items item: libraryItems) {
			if (item.getTitle().equalsIgnoreCase(title) && item.getItemType().equals(itemType)) {
				exist = true;
				System.out.println("Exist Item Number: " + item.getItemNumber() +
                        " Title: " + item.getTitle() +
                        " Item Type: " + item.getItemType() +
                        " Borrowing Days: " + item.getCustomer().borrowDays() +
                        " Exceeds: " + item.exceedenceChecker() +
                        " Total Price: $" + item.TotalPrice());
                
                break;
            }
			}
			
		 if (exist == false) {
                System.out.println("Does not exist");
            }			
	}
	
	
	public ArrayList<Items> getLibraryItems() {
		return libraryItems;
	}

	public void setLibraryItems(ArrayList<Items> libraryItems) {
		this.libraryItems = libraryItems;
	}

}

