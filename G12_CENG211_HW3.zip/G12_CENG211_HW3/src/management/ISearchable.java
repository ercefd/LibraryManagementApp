package management;

public interface ISearchable {
	
	public void searchItem(String title);
	public void searchItem(String title,String itemType);
}
